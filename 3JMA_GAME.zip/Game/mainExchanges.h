#ifndef MAINEXCHANGE_H
#define MAINEXCHANGE_H

#include "place.h"
#include "character.h"
 
int exchangesGame(Place *map, Place *textRect, Place *infoRect, character *amok);

#endif  /* MAINEXCHANGE_H */

