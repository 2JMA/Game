#ifndef MAINFINAL_H
#define MAINFINAL_H

#include "place.h"
#include "character.h"
 
int finalGame(Place *map, Place *textRect, Place *infoRect, character *Camok);

#endif  /* MAINFINAL_H */
