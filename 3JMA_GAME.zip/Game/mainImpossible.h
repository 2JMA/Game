#ifndef MAINIMPOSSIBLE_H
#define MAINIMPOSSIBLE_H

#include "place.h"
#include "character.h"
 
int mainImpossible(Place *map, Place *textRect, Place *infoRect, character *amok);

#endif  /* MAINIMPOSSIBLE_H */