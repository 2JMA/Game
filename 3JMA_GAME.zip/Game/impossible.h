#include "character.h"
#include "image.h"
#include "impossible.h"


thread_function_move_recta1(character* mChar);

thread_function_move_recta2(character* mChar);

thread_function_move_cuadrado1(character* mChar);

thread_function_move_cuadrado2(character* mChar);

thread_function_move_cuadrado3(character* mChar);

thread_function_move_diagonal1(character* mChar);

thread_function_move_diagonal2(character* mChar);

int impossible_level_1(character* mChar, character* mChar1, character* mChar2);

int impossible_level_2(character* mChar, character* mChar1, character* mChar2);

int impossible_level_3(character* mChar, character* mChar1, character* mChar2, character* mChar3);

int impossible_level_4(character* mChar, character* mChar1, character* mChar2, character* mChar3, character* mChar4, character* mChar5);

