#ifndef MAINQUESTIONS_H
#define MAINQUESTIONS_H

#include "place.h"
#include "character.h"
 
int questionGame(Place *map, Place *textRect, Place *infoRect, character *amok);

#endif  /* MAINQUESTIONS_H */